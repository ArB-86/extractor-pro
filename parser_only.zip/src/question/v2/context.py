from __future__ import annotations

import re

from src.question.rules import RuleEngine
from src.question.v2.state import ParserState, SuppressionZone


class StructuralPatterns:

    # Updated to match multi-level numbers: 1.3, 1.6, 1.6.1, 2.4.3, etc.
    SECTION = re.compile(
        r"""
        ^
        \s*
        \d+
        (?:\.\d+)+
        \s+
        [A-Za-z]
        """,
        re.X,
    )

    SECTION_LABEL = re.compile(
        r"^\s*section\s+\S",
        re.I,
    )

    ANSWER_HEADER = re.compile(
        r"^\s*(answers?|solutions?|hints?)\b",
        re.I,
    )


_ZONE_BLOCKS = {
    "example": SuppressionZone.EXAMPLE,
    "activity": SuppressionZone.ACTIVITY,
    "misc": SuppressionZone.MISCELLANEOUS,
    "figure_it_out": SuppressionZone.FIGURE_IT_OUT,
    "summary": SuppressionZone.SUMMARY,
    "historical": SuppressionZone.HISTORICAL,
}


class ContextManager:

    def __init__(self):

        self.rules = RuleEngine()

        self.state = ParserState()

    def update(self, region):

        state = self.state

        if region.page != state.page:

            state.page = region.page

            state.region_index = 0

        text = " ".join(
            (region.text or "").split()
        )

        label = region.label

        result = self.rules.analyze(text)

        block = result.block_type

        state.metadata["text"] = text

        state.metadata["label"] = label

        state.metadata["last_block"] = block

        if block == "chapter":

            state.chapter = text

            state.chapter_number = self._chapter_number(text)

            state.exercise = None

            state.section = None

            state.reset_question()

            state.exit_zone()

        elif block == "exercise":

            state.exercise = text

            state.reset_question()

            state.exit_zone()

        # ----- UPDATED SECTION DETECTION (label‑independent) -----
        elif (
            StructuralPatterns.SECTION.match(text)
            or StructuralPatterns.SECTION_LABEL.match(text)
        ):

            state.section = text

            # Explicitly reset question state
            state.question_number = None
            state.question_open = False

            state.exit_zone()

            # If this looks like a numbered section, also update chapter context
            m = re.match(r"^\s*(\d+\.\d+)", text)
            if m:
                state.chapter = text

        # zone handling
        zone = _ZONE_BLOCKS.get(block)

        # Figure It Out contains real questions and should not suppress extraction.
        if zone is SuppressionZone.FIGURE_IT_OUT:
            state.exit_zone()
            # Do not enter zone; continue processing
        elif zone is not None:
            # DEBUG: print zone entry
            print(
                f"[ZONE] block={block} "
                f"zone={state.zone} "
                f"text={text[:80]!r}"
            )

            state.enter_zone(zone)

        elif StructuralPatterns.ANSWER_HEADER.match(text):
            # DEBUG: print answer zone entry
            print(
                f"[ZONE] block={block} "
                f"zone={state.zone} "
                f"text={text[:80]!r}"
            )

            state.enter_zone(
                SuppressionZone.ANSWER
            )

        state.next_region()

        return state

    @staticmethod
    def _chapter_number(text):

        m = re.search(r"\d+", text)

        if m:

            return int(m.group())

        return None
