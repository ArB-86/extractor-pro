from __future__ import annotations

import re

from src.question.models import QuestionCandidate


class QuestionValidator:
    """Validate and clean question candidates before conversion."""

    def validate(self, candidates: list[QuestionCandidate]) -> list[QuestionCandidate]:
        """Filter out invalid candidates and clean text."""
        valid = []

        for q in candidates:
            if q is None:
                continue

            text = q.text or ""

            # 1. Drop answer blocks
            text = re.sub(
                r"(?ims)^ans(?:wer)?\.?.*$",
                "",
                text,
            )
            text = re.sub(
                r"(?ims)^solution\.?.*$",
                "",
                text,
            )

            # 2. Remove OCR artifacts
            text = re.sub(
                r"OCR\([^)]*\)",
                "",
                text,
            )
            text = re.sub(
                r"\bQ\.\s*$",
                "",
                text,
                flags=re.M,
            )

            # 3. Drop page noise
            text = re.sub(
                r"(?im)^page\s+\d+.*$",
                "",
                text,
            )
            text = re.sub(
                r"(?im)^.*age\s+\d+.*$",
                "",
                text,
            )

            # 4. Collapse whitespace
            text = re.sub(r"\n{2,}", "\n", text)
            text = re.sub(r"[ \t]+", " ", text)
            text = text.strip()

            # 5. Reject OCR-heavy / too‑short questions
            alpha = sum(c.isalpha() for c in text)
            if alpha < 10:
                continue

            if len(text.split()) < 4:
                continue

            # Update the candidate with cleaned text
            q.text = text
            valid.append(q)

        return valid
