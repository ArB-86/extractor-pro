from __future__ import annotations

import re

from src.document.document import Document

from src.question.v2.context import ContextManager
from src.question.v2.numbering import NumberingDetector
from src.question.v2.boundary import BoundaryDetector
from src.question.v2.assembler import QuestionAssembler
from src.question.v2.classifier import QuestionClassifier
from src.question.v2.validator import QuestionValidator
from src.question.v2.converter import CandidateConverter


class QuestionExtractorV2:

    def __init__(self):

        self.context = ContextManager()

        self.numbering = NumberingDetector()

        self.boundary = BoundaryDetector()

        self.assembler = QuestionAssembler()

        self.classifier = QuestionClassifier()

        self.validator = QuestionValidator()

        self.converter = CandidateConverter()

    def extract(
        self,
        document: Document,
    ):

        state = self.context.state

        for region in document.regions:

            if not region.text:
                continue

            state = self.context.update(region)

            # Split the normalized text into potential question chunks
            for chunk in self._split_questions(state.metadata["text"]):
                text = chunk.strip()
                if not text:
                    continue

                signal = self.numbering.read(text)

                boundary = self.boundary.classify(
                    text=text,
                    state=state,
                    signal=signal,
                )

                # DEBUG: print boundary, signal, and first 80 chars of text
                print(
                    f"[DBG] boundary={boundary} "
                    f"signal={signal.kind} "
                    f"text={text[:80]!r}"
                )

                # ADDED: Assembler state debug
                print(
                    f"[ASM] "
                    f"qno={state.question_number!r} "
                    f"open={state.question_open} "
                    f"boundary={boundary.value} "
                    f"signal={signal.kind!r}"
                )

                self.assembler.consume(
                    text=text,
                    state=state,
                    boundary=boundary,
                    signal=signal,
                )

        questions = self.assembler.finalize(
            state,
        )

        print(
            f"[QuestionExtractor] assembled {len(questions)} candidates"
        )

        questions = self.classifier.classify(
            questions,
        )

        questions = self.validator.validate(
            questions,
        )

        questions = self.converter.convert(
            questions,
        )

        print(
            f"[QuestionExtractor] converted {len(questions)} questions"
        )

        return questions

    @staticmethod
    def _split_questions(text: str) -> list[str]:
        """Split text into chunks that each start with a question number pattern."""
        text = text.strip()
        if not text:
            return []

        parts = re.split(
            r"(?=(?:Q\.?\s*)?\d+[.)]\s+)",
            text,
        )

        return [
            p.strip()
            for p in parts
            if p.strip()
        ]
