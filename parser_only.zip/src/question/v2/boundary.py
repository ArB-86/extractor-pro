from __future__ import annotations

import re
from enum import Enum

from src.question.v2.context import StructuralPatterns
from src.question.v2.numbering import (
    NumberSignal,
    NumberingPatterns,
)
from src.question.v2.state import ParserState


class LineClass(str, Enum):
    QUESTION_START = "question_start"
    QUESTION_BODY = "question_body"
    OPTION = "option"
    SUBQUESTION = "subquestion"
    HEADER = "header"
    DROP = "drop"


_CAPTION = re.compile(r"^\s*(figure|fig\.?|table|chart|graph)\b", re.I)
_PAGE = re.compile(r"^\s*\d+\s*$")
_ALNUM = re.compile(r"[A-Za-z0-9]")
_CUE = re.compile(
    r"\b(find|solve|show|calculate|determine|prove|evaluate|write|state|define|what|which|why|how|construct|draw|verify|identify|simplify|factorise|expand)\b",
    re.I,
)


class BoundaryDetector:

    SUMMARY_HEADERS = (
        "summary",
        "chapter summary",
        "umm",
        "um m",
    )

    DROP_PREFIXES = (
        "ocr(",
        "page no",
        "page ",
        "figure it out",
        "figure it o1 ut",
        "figure it",
    )

    ANSWER_PREFIXES = (
        "ans.",
        "answer",
        "solution",
        "we get",
        "which is",
        "this is",
        "yes.",
        "yes,",
        "therefore",
        "hence",
        "for picture",
        "refer table",
        "refer figure",
    )

    EXPLANATION_PREFIXES = (
        "this is",
        "we get",
        "which is",
        "for picture",
        "refer",
        "yes,",
        "therefore",
        "hence",
        "thus",
    )

    def classify(
        self,
        *,
        text: str,
        state: ParserState,
        signal: NumberSignal,
    ) -> LineClass:

        text = text.strip()
        lower = text.lower()

        if not text:
            return LineClass.DROP

        # ----- Drop numbered answer lines -----
        if re.match(r"^\(?\d+\)?\s*ans", lower):
            return LineClass.DROP

        # ----- Drop OCR formulas with many '+' and few letters -----
        alpha = sum(c.isalpha() for c in text)
        if alpha < 8 and text.count("+") >= 2:
            return LineClass.DROP

        # ----- Explanatory prefixes: continue or drop -----
        if any(lower.startswith(x) for x in self.EXPLANATION_PREFIXES):
            return LineClass.QUESTION_BODY if state.question_open else LineClass.DROP

        if re.match(r"^[A-Za-z]\s*age\s+\d+", text, re.I):
            return LineClass.DROP

        if any(lower.startswith(x) for x in self.DROP_PREFIXES):
            return LineClass.DROP

        if any(lower.startswith(x) for x in self.SUMMARY_HEADERS):
            return LineClass.HEADER

        if re.fullmatch(r"[qQ]\.?", text):
            return LineClass.DROP

        if re.fullmatch(r"\d+", text):
            return LineClass.DROP

        if re.fullmatch(r"page\s*no\.?\s*\d+", lower):
            return LineClass.DROP

        if re.fullmatch(r"s\s*section\s*\d+.*", lower):
            return LineClass.DROP

        if lower.startswith(self.ANSWER_PREFIXES):
            return LineClass.DROP

        if lower in {"section", "exercise", "chapter"}:
            return LineClass.HEADER

        if sum(c.isalpha() for c in text) < 5 and any(c.isdigit() for c in text):
            return LineClass.DROP

        print(
            f"[SUPPRESS] zone={state.zone} "
            f"signal={signal.kind} "
            f"text={text[:80]!r}"
        )

        if state.suppressed:
            return LineClass.DROP

        if _PAGE.match(text):
            return LineClass.DROP

        if _CAPTION.match(text):
            return LineClass.DROP

        block = state.metadata.get("last_block")
        label = state.metadata.get("label")

        if block in ("chapter", "exercise"):
            return LineClass.HEADER

        if label == "title" and StructuralPatterns.SECTION.match(text):
            return LineClass.HEADER

        if label == "plain_text" and StructuralPatterns.SECTION_LABEL.match(text):
            return LineClass.HEADER

        if signal.kind == "option":
            return LineClass.OPTION if state.question_open else LineClass.DROP

        if signal.kind == "subquestion":
            return LineClass.SUBQUESTION if state.question_open else LineClass.DROP

        # ---------- QUESTION START HANDLING ----------
        if signal.kind == "question":
            remainder = NumberingPatterns.QUESTION_NUMBER.sub(
                "",
                text,
                count=1,
            ).strip()
            lower_rem = remainder.lower()

            # Stronger prefix check (also catches answer lines)
            if any(lower_rem.startswith(x) for x in self.ANSWER_PREFIXES):
                return LineClass.DROP

            # Specific patterns that are definitely not questions
            if (
                lower_rem.startswith("5. this is")
                or lower_rem.startswith("3. number of")
                or lower_rem.startswith("1) ans")
            ):
                return LineClass.DROP

            # Drop answer-style patterns
            if re.match(r"^\d+(,\s*\d+)+", remainder):
                return LineClass.DROP
            if "we get" in lower_rem and "?" not in remainder:
                return LineClass.DROP
            if "for picture" in lower_rem:
                return LineClass.DROP

            # Explanatory prefixes – treat as body or drop
            if any(lower_rem.startswith(x) for x in self.EXPLANATION_PREFIXES):
                return LineClass.QUESTION_BODY if state.question_open else LineClass.DROP

            # Existing rejection for answer prefixes (already covered)
            if lower_rem.startswith(("ans.", "answer", "solution", "hint")):
                return LineClass.DROP

            if sum(c.isalpha() for c in remainder) < 5:
                return LineClass.DROP

            if re.fullmatch(r"[,.\d ]+", remainder):
                return LineClass.DROP

            if self._looks_like_heading(remainder):
                return LineClass.HEADER

            return LineClass.QUESTION_START
        # ------------------------------------

        # Before returning QUESTION_BODY, check for answer/explanation prefixes
        if state.question_open:
            if any(lower.startswith(x) for x in self.ANSWER_PREFIXES):
                return LineClass.DROP
            if (
                lower.startswith("5. this is")
                or lower.startswith("3. number of")
                or lower.startswith("1) ans")
            ):
                return LineClass.DROP

        return LineClass.QUESTION_BODY if state.question_open else LineClass.DROP

    def _looks_like_heading(self, text: str) -> bool:
        lower = text.lower()

        if _CUE.search(text):
            return False

        if "?" in text:
            return False

        if "=" in text or "+" in text or "×" in text:
            return False

        if lower.startswith(("find", "solve", "draw", "write")):
            return False

        if len(text.split()) > 8:
            return False

        if text.endswith(":"):
            return True

        return (
            text == text.title()
            and not text.endswith("?")
        )
