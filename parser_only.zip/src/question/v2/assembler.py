from __future__ import annotations

from src.question.models import (
    QuestionCandidate,
    QuestionContext,
)

from src.question.v2.boundary import LineClass
from src.question.v2.numbering import NumberSignal
from src.question.v2.state import ParserState


class QuestionAssembler:

    def __init__(self):

        self.current = None
        self.questions = []

    def _flush(self):

        if self.current:

            self.current.text = self.current.text.strip()

            if self.current.text:

                self.questions.append(
                    self.current
                )

        self.current = None

    def consume(
        self,
        *,
        text: str,
        state: ParserState,
        boundary: LineClass,
        signal: NumberSignal,
    ):

        text = text.strip()

        if not text:
            return

        if boundary in (
            LineClass.DROP,
            LineClass.HEADER,
        ):
            return

        if boundary == LineClass.QUESTION_START:

            self._flush()

            state.question_open = True
            state.question_number = signal.value

            self.current = QuestionCandidate(

                number=signal.value,

                text=text,

                context=QuestionContext(

                    chapter=state.chapter,

                    exercise=state.exercise,

                    page=state.page,

                ),

            )

            return

        if self.current is None:
            return

        if boundary == LineClass.OPTION:

            self.current.metadata.setdefault(
                "option_count",
                0,
            )

            self.current.metadata["option_count"] += 1

            self.current.text += "\n" + text

            return

        if boundary == LineClass.SUBQUESTION:

            self.current.text += "\n" + text

            return

        if boundary == LineClass.QUESTION_BODY:

            self.current.text += "\n" + text

    def finalize(
        self,
        state: ParserState | None = None,
    ):

        self._flush()

        if state is not None:

            state.question_open = False
            state.question_number = None

        return self.questions
