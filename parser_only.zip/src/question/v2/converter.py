from __future__ import annotations

import re

from rapidfuzz import fuzz

from src.document.question import Question
from src.question.models import QuestionCandidate


class CandidateConverter:

    SIMILARITY = 98.0

    @staticmethod
    def _normalize(text: str) -> str:

        text = text.lower()

        text = re.sub(r"\s+", " ", text)

        text = re.sub(r"[^\w ]", "", text)

        return text.strip()

    def convert(
        self,
        candidates: list[QuestionCandidate],
    ) -> list[Question]:

        output: list[Question] = []

        seen: dict[
            tuple[str, str | None],
            list[str],
        ] = {}

        for q in candidates:

            key = (
                q.number,
                q.context.chapter,
            )

            norm = self._normalize(q.text)

            duplicate = False

            for previous in seen.get(key, ()):

                if (
                    fuzz.ratio(
                        norm,
                        previous,
                    )
                    >= self.SIMILARITY
                ):
                    duplicate = True
                    break

            if duplicate:
                continue

            seen.setdefault(
                key,
                [],
            ).append(norm)

            output.append(

                Question(

                    question_text=q.text,

                    chapter=q.context.chapter,

                    exercise=q.context.exercise,

                    question_number=q.number,

                    question_type=q.qtype.value,

                    confidence=q.confidence,

                    metadata=q.metadata,

                )

            )

        return output
