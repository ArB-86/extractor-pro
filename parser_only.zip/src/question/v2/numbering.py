from __future__ import annotations

import re
from dataclasses import dataclass


class NumberingPatterns:

    # Stricter pattern: only numbers ≥1, followed by . or ), and then a letter or '('
    QUESTION_NUMBER = re.compile(
        r"""
        ^
        \s*
        (?:
            Question\s+
          | Q\.?\s*
        )?
        ([1-9]\d*)
        [.)]
        \s+
        (?=[A-Z(])
        """,
        re.I | re.X,
    )

    SUBQUESTION = re.compile(
        r"""
        ^
        \s*
        (
            \([a-z]\)
            |
            \([ivxlcdm]+\)
            |
            [a-z][.)]
            |
            [ivxlcdm]+[.)]
        )
        \s+
        """,
        re.I | re.X,
    )

    OPTION = re.compile(
        r"^\s*\([A-D]\)",
        re.I,
    )


@dataclass(slots=True, frozen=True)
class NumberSignal:
    kind: str | None
    value: str | None = None


class NumberingDetector:

    def read(
        self,
        text: str,
    ) -> NumberSignal:

        text = text.strip()

        m = NumberingPatterns.QUESTION_NUMBER.match(text)

        if m:

            remainder = text[m.end():].strip().lower()

            # Early reject common OCR answer/artifact starts
            BAD_STARTS = (
                "ans",
                "answer",
                "solution",
                "page",
                "this is",
                "which is",
                "we get",
                "number of",
                "for picture",
                "refer",
            )

            if any(remainder.startswith(x) for x in BAD_STARTS):
                return NumberSignal(kind=None)

            # Also reject if the remainder is just a page number or pure digits
            if re.match(r"^\d+$", remainder):
                return NumberSignal(kind=None)

            return NumberSignal(
                kind="question",
                value=m.group(1),
            )

        if NumberingPatterns.OPTION.match(text):
            return NumberSignal(kind="option")

        m = NumberingPatterns.SUBQUESTION.match(text)

        if m:
            token = m.group(1).strip().lower()
            if token == "q.":
                return NumberSignal(kind=None)
            return NumberSignal(
                kind="subquestion",
                value=m.group(1),
            )

        return NumberSignal(kind=None)
