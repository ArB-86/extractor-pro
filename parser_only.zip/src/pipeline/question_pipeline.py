from __future__ import annotations

from src.question.deduplicator import QuestionDeduplicator
from src.question.v2.extractor import QuestionExtractorV2


class QuestionPipeline:

    def __init__(self):

        self.extractor = QuestionExtractorV2()

        self.deduplicator = QuestionDeduplicator()

    def run(
        self,
        document,
    ):

        questions = self.extractor.extract(
            document,
        )

        questions = self.deduplicator.deduplicate(
            questions,
        )

        return questions
