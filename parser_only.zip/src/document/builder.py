from src.document.document import Document
from src.postprocess.region_merger import RegionMerger
from src.reading_order.geometry_sorter import GeometrySorter
from src.text.cleaner import TextCleaner


class DocumentBuilder:

    @staticmethod
    def build(regions):

        if not regions:
            return Document(
                pages=0,
                regions=[],
            )

        regions = GeometrySorter.sort(regions)
        regions = RegionMerger.merge(regions)

        for r in regions:
            if r.text:
                r.text = TextCleaner.clean(r.text)

        doc = Document(
            pages=max(r.page for r in regions),
        )

        for r in regions:
            doc.add_region(r)

        return doc
