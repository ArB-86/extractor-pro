import json


def save_json(data, path):

    with open(path, "w", encoding="utf-8") as f:
        json.dump(
            data,
            f,
            indent=4,
            ensure_ascii=False,
        )


def load_json(path):

    with open(path, encoding="utf-8") as f:
        return json.load(f)
