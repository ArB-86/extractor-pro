from __future__ import annotations

from typing import Any, List

from ..base import BaseSplitter


class MiscSplitter(BaseSplitter):

    name = "misc"

    priority = 390

    def split(self, blocks: List[Any]) -> List[Any]:
        return blocks
